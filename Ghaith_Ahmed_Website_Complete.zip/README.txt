GHAITH AHMED WEBSITE — COMPLETE PROTOTYPE

Files:
- index.html — website
- style.css — design
- script.js — demo login/dashboard

Demo client login:
Phone: +9647000000000
Password: 123456

IMPORTANT:
This is a front-end prototype. The login is NOT secure production authentication.
For a real client system, connect it to a secure backend such as Supabase Auth + PostgreSQL Row Level Security.

To publish:
1. Upload the website files to a static hosting service such as Vercel.
2. Deploy the folder containing index.html, style.css and script.js.
3. The site will receive a public web address.

Do not put private passwords, database service keys, or Supabase service-role keys into these files.
