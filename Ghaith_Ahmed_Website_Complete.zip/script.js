const modal=document.getElementById('loginModal'), dash=document.getElementById('dashboard');
function openLogin(){modal.style.display='flex';document.getElementById('loginMsg').textContent=''}
function closeLogin(){modal.style.display='none'}
function closeDashboard(){dash.style.display='none'}
function login(){
  const phone=document.getElementById('phone').value.trim(), pass=document.getElementById('password').value;
  if((phone==='+9647000000000'||phone==='07000000000')&&pass==='123456'){
    closeLogin();dash.style.display='flex';
  }else document.getElementById('loginMsg').textContent='Demo login: +9647000000000 / 123456';
}
window.onclick=e=>{if(e.target===modal)closeLogin();if(e.target===dash)closeDashboard();}
